import { RupeeFormatPipe } from './rupee-format.pipe';

describe('RupeeFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new RupeeFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
